<?php
echo "<br><br><br><br><br><br><br><br><center><p><b>Copyright &copy; 2024-", date(2024)."Integrative Programming & Tech IT<b></center></br></br></br></br></br></br></br></p>"
?>